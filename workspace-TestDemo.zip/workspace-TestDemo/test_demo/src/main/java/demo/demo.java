package demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo {

	public static String driverPath = "C:\\Users\\Dell\\Desktop\\New folder\\";

	public static void main(String args[]) throws InterruptedException
	{
		
	System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.ecwid.com/in");
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	
	WebElement signup = driver.findElement(By.xpath("//*[@id='header']/div/div[3]/div[1]/a"));
	signup.click();
	
	WebElement fname = driver.findElement(By.name("name"));
	fname.sendKeys("Vijay Patil");
	
	WebElement fieldset1 = driver.findElement(By.cssSelector("form.create-form > div > div:nth-child(4) > div:nth-child(2) > div.fieldset__field-wrapper > div.field.field--large"));
	fieldset1.click();
	
	WebElement email = fieldset1.findElement(By.name("email"));
	email.click();
	email.sendKeys("shubhs@mailinator.com");
	
	
	WebElement fieldset2 = driver.findElement(By.cssSelector("form.create-form > div > div:nth-child(5) > div:nth-child(2) > div.fieldset__field-wrapper > div.field.field--large"));
	fieldset2.click();
	
	WebElement passwd = fieldset2.findElement(By.name("password"));
	passwd.click();
	passwd.sendKeys("123456");
	
	WebElement register = driver.findElement(By.cssSelector("form.create-form > div > button"));
	register.click();
	
	
	
	}
}
